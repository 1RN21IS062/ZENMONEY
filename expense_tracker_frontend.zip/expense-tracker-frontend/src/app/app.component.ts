import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <h1>Expense & Income Tracker</h1>
    <app-transaction-form (transactionAdded)="refreshList()"></app-transaction-form>
    <app-transaction-list></app-transaction-list>
  `
})
export class AppComponent {
  refreshList() {}
}