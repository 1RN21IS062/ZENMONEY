import { Component, EventEmitter, Output } from '@angular/core';
import { TransactionService } from '../../services/transaction.service';

@Component({
  selector: 'app-transaction-form',
  template: `
    <form (submit)="addTransaction()">
      <input [(ngModel)]="description" name="desc" placeholder="Description" required />
      <input [(ngModel)]="amount" name="amt" placeholder="Amount" type="number" required />
      <select [(ngModel)]="type" name="type" required>
        <option value="income">Income</option>
        <option value="expense">Expense</option>
      </select>
      <button type="submit">Add</button>
    </form>
  `
})
export class TransactionFormComponent {
  description = '';
  amount = 0;
  type = 'income';

  @Output() transactionAdded = new EventEmitter<void>();

  constructor(private service: TransactionService) {}

  addTransaction() {
    this.service.addTransaction({
      description: this.description,
      amount: this.amount,
      type: this.type
    }).subscribe(() => this.transactionAdded.emit());
  }
}