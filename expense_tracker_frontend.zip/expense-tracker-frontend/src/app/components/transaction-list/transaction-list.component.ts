import { Component, OnInit } from '@angular/core';
import { TransactionService } from '../../services/transaction.service';

@Component({
  selector: 'app-transaction-list',
  template: `
    <ul>
      <li *ngFor="let tx of transactions">
        {{tx.description}} - {{tx.amount}} ({{tx.type}})
        <button (click)="deleteTransaction(tx.id)">X</button>
      </li>
    </ul>
  `
})
export class TransactionListComponent implements OnInit {
  transactions: any[] = [];

  constructor(private service: TransactionService) {}

  ngOnInit() {
    this.loadTransactions();
  }

  loadTransactions() {
    this.service.getTransactions().subscribe(data => this.transactions = data);
  }

  deleteTransaction(id: number) {
    this.service.deleteTransaction(id).subscribe(() => this.loadTransactions());
  }
}